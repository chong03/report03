function zIO(){
    $('li').css({
            'z-index':0,
            'opacity':0
        });
}
function prev(index){
    if(index==1){
        $('li').eq(4).css('z-index',1).css('opacity',1);
    }else{
        $('li').eq(index-1).css('z-index',1).css('opacity',1);
    }
    
}
function next(index){
    if(index==4){
        $('li').eq(1).css('z-index',1).css('opacity',1);
    }else{
        $('li').eq(index+1).css('z-index',1).css('opacity',1);
    }
    
}
function zIO4(){
    for(let cnt=1;cnt<=4;cnt++){
        if($('li').eq(cnt).css('z-index')==1){
            return cnt;
        }
    }
}
function fadeSlider(){
    cnt = zIO4();
    zIO();
    return cnt;
};
